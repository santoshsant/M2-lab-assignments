import{Mobile} from './mobile';

export class Smartphone extends Mobile{
    mobileType:string;
    constructor(mobilesp)
    {
        super(101,"Nokia",565463);
        this.mobileType=mobilesp;
    }
    printMobileDetails()
    {
        super.printMobileDetails();
        console.log("Mobile Type of basic phone: "+this.mobileType);
    }
}